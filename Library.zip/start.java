import Frames.Homepage;
import java.lang.*;
public class start
{
	public static void main(String[] args)
	{
		new Homepage();
	}
}