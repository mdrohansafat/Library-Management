package Interfaces;
public interface IManageBooksOperations
{
	void displayBooks();
	void updateBook();
	void searchBook();
	void deleteBook();
}